<?php get_header(); ?>
<div class="row d-flex justify-content-center p-4">
<!-- blog posts -->
<?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
    <!-- post structure -->
    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 my-4"> 
        <!-- begin of card -->
        <div class="card border-celeste">
            <!-- thumbnail image with link-->    
            <a href="<?php the_permalink(); ?>">
            <?php if(has_post_thumbnail()) : ?>
            <?php the_post_thumbnail( 'full', array( 'class'=>'card-img-top rounded' ) ); ?>
            <?php endif; ?></a>
        
            <div class="card-body bg-pearl text-darkerblue mt-2">
                <!-- content -->
                <a href="<?php the_permalink(); ?>">
                <h5 class="card-title text-pink"><?php the_title(); ?></h5></a>
                <p class="card-text"><?php the_excerpt(); ?></p>
                 <small class="text-celeste">
                    <?php the_time('F j, Y - g:i a'); ?>
                        | author: <?php the_author(); ?>
                </small>
            </div>
        <!-- end of card -->
        </div>
    <!-- end of col -->
    </div>
<?php endwhile; ?>
<?php else : ?>
<p class="text-darkerblue"><?php__( 'No Posts Found'); ?></p>
<?php endif; ?>
<!-- end of row -->
</div>
<!-- end of container -->
</div>
<?php get_footer(); ?>
