<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <title><?php bloginfo('name'); ?></title>
    <!-- stylesheets -->
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Shrikhand&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <?php wp_head(); ?>
  </head>
<body>
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-celeste border-pink" role="navigation" id="navi">
    
    <a class="navbar-brand font-weight-bold shrikhand" href="index.php">Mount Everest</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
    <?php
      wp_nav_menu( array(
         'theme_location'    => 'primary',
         'depth'             => 2, // 1 = no dropdowns, 2 = dropdown
         'container'         => 'div',
         'container_class'   => 'collapse navbar-collapse',
         'container_id'      => 'navbarSupportedContent',
         'menu_class'        => 'navbar-nav',
         'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
         'walker'            => new WP_Bootstrap_Navwalker(),
      ) );
    ?>
  
  </nav>
<!-- begin of container -->
<div class="container-fluid">
  <div class="jumbotron background-photo d-flex justify-content-center align-items-center">
    <div class="text-center text-pearl shrikhand">
    <h1 class="display-4 font-weight-bold"><?php bloginfo('name'); ?></h1>
    <h2 class="display-6"><?php bloginfo('description'); ?></h2>
  </div>
</div>
