<?php get_header(); ?>
<div class="row p-2">
		<?php if(have_posts()) :  ?>
		<?php while(have_posts()) : the_post(); ?>
		<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
			<div class="col-12 border-lilac p-4 my-4 bg-pearl text-darkerblue">
				<div class="text-center">
					<h2 class="display-4 font-weight-bold text-pink"><?php the_title(); ?></h2>
				</div>
				<!-- thumbnail image -->
					<?php if(has_post_thumbnail()) : ?>
					<?php the_post_thumbnail( 'full', array( 'class'=>'img-fluid rounded' ) ); ?>
					<?php endif; ?>
				<!-- content -->
				<div class="my-4 text-justify">
					<?php the_content(); ?>
				</div>
				<!-- date and author -->
				<small class="my-4">
					<?php the_time('F j, Y - g:i a'); ?>
					| author: <?php the_author(); ?>
				</small>
				<!-- comment section -->
				<div class="pt-4">
					<?php comments_template(); ?>
				</div>
				<!-- views counter -->
				<div class="text-right">
					<small><?php echo getPostViews(get_the_ID());?></small>
				</div>
			</div>
		</div>
		<?php endwhile; ?>
		<!-- if there are no posts -->
		<?php else : ?>
		<p class="text-darkerblue"><?php__('Sorry no posts found!'); ?></p>
		<?php endif; ?>	
		<!-- sidebar -->
		<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 my-4">
			<?php if(is_active_sidebar('sidebar')):
				dynamic_sidebar('sidebar');
				endif;?>
		</div>
</div>
	<!-- button to go back to blog -->
	<div class="d-flex align-items-center py-4" onclick="history.back();">
		<button class="btn btn-sample" type="button"><i class="fa fa-arrow-left text-white"></i><span class="text-white ml-2">Back to the Blog</span></button>
	</div>
<!-- end of container -->
</div>
<?php get_footer(); ?>