<?php get_header(); ?>
<div class="row py-4">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
    <div class="border-pearl bg-celeste mx-4 p-3">
      <h1 class="shrikhand display-4 py-4">Visit the World</h1>
      <p>Nulla facilisis orci risus, id pharetra urna porta at. Pellentesque erat urna, varius ut mollis quis, ultricies et ante.</p>
      <a class="btn btn-sample btn-lg text-white" href="?page_id=2">visit our blog</a>
    </div>
  </div>
</div>
<div class="row d-flex justify-content-center py-4 my-4">
  <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 bg-cobalt text-center border-db text-pearl my-2 p-4">   
     <i class="fa fa-laptop fa-4x pb-2 text-pink"></i>
      <h3>Book from Home or Anywhere</h3>
      <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 bg-cobalt text-pearl border-db mx-4 my-2 text-center p-4">       
      <i class="fa fa-star fa-4x pb-2 text-pink"></i>
      <h3>Five Star Customer Service</h3>
      <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>      
  </div>
  <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 bg-cobalt text-pearl border-db text-center my-2 p-4">     
      <i class="fa fa-fort-awesome fa-4x pb-2 text-pink"></i>
      <h3>Visit extraordinary Places</h3>
      <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>        
  </div>
</div>
<?php get_footer(); ?>