<?php get_header(); ?>
<div class="row d-flex justify-content-center">
			<div class="jumbotron jumbotron-fluid rounded p-4">
			  <div class="container">
			  	<!-- featured imaege -->
			  	<?php if(has_post_thumbnail()) : ?>
				<?php the_post_thumbnail( 'full', array( 'class'=>'img-fluid rounded' ) ); ?>
				<?php endif; ?>
			    <h1 class="display-4 text-center text-darkerblue font-weight-bold"><?php the_title(); ?></h1>
			  </div>
			</div>
			<!-- posts -->
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p-4">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<!-- content -->
			<div class="my-4 text-justify p-4">
				<?php the_content(); ?>
			</div>
		</div>
			<?php endwhile; endif; ?>
		</div>
</div>
<?php get_footer(); ?>